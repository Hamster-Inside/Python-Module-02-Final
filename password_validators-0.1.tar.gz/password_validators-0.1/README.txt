A small python code to test if password is strong and check if it leaked somewhere by pwnd

* You need to add file 'passwords.txt' inside the 'Secrets' folder with some passwords to be checked, separated by new line
